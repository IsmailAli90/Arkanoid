//Ismail Ali and Jeffrey Zhu
//Arkanoid Project
//2018-02-20
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.MouseInfo;

public class Arkanoid5 extends JFrame implements ActionListener{
	Timer myTimer;//timer
	GamePanel game;
	public int bally = 0;//y location of the ball
    public Arkanoid5(){
		super("Arkanoid");//title
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800,700);//size of the screen 800 length 700 width

		myTimer = new Timer(10, this);	 // trigger every 10 ms

		game = new GamePanel(this);
		add(game);

		setResizable(false);//so screen is not resizable
		setVisible(true);
    }
	public void start(){
		myTimer.start();
	}
	public void actionPerformed(ActionEvent evt){
		game.move();
		game.repaint();
	}
    public static void main(String[] arguments){
		Arkanoid5 frame = new Arkanoid5();
    }
}
class GamePanel extends JPanel implements KeyListener{
	private int padx,pady;//pad x and pad y location
	private int ballx,bally,oppp,distx,disty,fast,collided,Lives,deathTimer,score,deadBlocks;//these numbers will be explained later
	private boolean []keys;
	
	private boolean colRW,colLW,colTW,colPAD,colLPAD,colRPAD,UP,DOWN,LEFT,RIGHT;
	boolean started = false;//the game didn't start yet so it is false
	private Arkanoid5 mainFrame;
	private int[][]LivesB={//Lives of the blocks, the top is 2 because it requires 2 hits
		{2,2,2,2,2,2,2,2,2,2,2},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1}
		};
	Image back,pad,blocks, ball,GG,Continue,LivesPic,LevelComplete;//Images used in game
	Image YBrick,DBBrick,SBrick,RBrick,GBrick,PBrick;//Bricks
	public GamePanel(Arkanoid5 m){
		keys = new boolean[KeyEvent.KEY_LAST+1];//if you press a key
		back = new ImageIcon("back1.png").getImage();
		back = back.getScaledInstance(700,600,Image.SCALE_SMOOTH);
		pad = new ImageIcon("arkanoidpad.png").getImage();
		pad = pad.getScaledInstance(100,25,Image.SCALE_SMOOTH);							//
		ball = new ImageIcon("ball.png").getImage();
		
		GG = new ImageIcon("GG.jpg").getImage();
		GG = GG.getScaledInstance(300,150,Image.SCALE_SMOOTH);
		Continue = new ImageIcon("Continue.png").getImage();							//Images when game is finished or failed
		Continue = Continue.getScaledInstance(300,150,Image.SCALE_SMOOTH);
		LevelComplete = new ImageIcon("LevelComplete.jpg").getImage();
		LevelComplete = LevelComplete.getScaledInstance(300,150,Image.SCALE_SMOOTH);
		LivesPic = new ImageIcon("Lives.png").getImage();
		LivesPic = LivesPic.getScaledInstance(50,50,Image.SCALE_SMOOTH);
		
		YBrick = new ImageIcon("Yellow.png").getImage();
		YBrick = YBrick.getScaledInstance(60,31,Image.SCALE_SMOOTH);
		DBBrick = new ImageIcon("DarkBlue.png").getImage();
		DBBrick = DBBrick.getScaledInstance(60,31,Image.SCALE_SMOOTH);
		SBrick = new ImageIcon("Silver.png").getImage();
		SBrick = SBrick.getScaledInstance(60,31,Image.SCALE_SMOOTH);
		RBrick = new ImageIcon("Red.png").getImage();						//Bricks
		RBrick = RBrick.getScaledInstance(60,31,Image.SCALE_SMOOTH);
		GBrick = new ImageIcon("Green.png").getImage();
		GBrick = GBrick.getScaledInstance(60,31,Image.SCALE_SMOOTH);
		PBrick = new ImageIcon("Pink.png").getImage();
		PBrick = PBrick.getScaledInstance(60,31,Image.SCALE_SMOOTH);
		mainFrame = m;

		ballx = 395;
		bally = 523;
    	padx = 360;
   		pady = 550;
        
        deadBlocks=0;//number of dead blocks
        	
        Lives= 3;//number of lives
		setSize(800,600);
        addKeyListener(this);
	}
    public void addNotify(){
        super.addNotify();
        requestFocus();
        mainFrame.start();
    }
	public void move(){
		if(keys[KeyEvent.VK_RIGHT]){//moving pad right. If started is false ball will move right too
			if(started==false){
				if(padx<625){//boundary
					padx += 5;
					ballx += 5;
				}
			}
			else{
				if(padx<625){
					padx += 5;
				}
			}
		}
		if(keys[KeyEvent.VK_LEFT]){
			if(started==false){
				if(padx>75){
					padx -= 5;
					ballx -= 5;
				}
			}
			else{
				if(padx>75){
					padx -= 5;
				}
			}
		}//369 496 457 517
		if(keys[KeyEvent.VK_SPACE]==true){//Start game when space is pressed
			if(bally==523 && started==false){
				started=true;
				UP = true;//Start the game going up
				DOWN = false;
				RIGHT = true;
				LEFT = false;
			}
			
		}
		Point mouse = MouseInfo.getPointerInfo().getLocation();
		Point offset = getLocationOnScreen();

	}
	public void moveBall(){
		
		if(ballx>=695){ //hit the right wall
			LEFT = true;
			RIGHT = false;
		}
		if(bally<=70){//hit the top wall
			DOWN = true;
			UP = false;
		}
		if(ballx<=70){ //hit the left wall
			RIGHT = true;
			LEFT = false;
		}
		
		if(bally==522){//if the ball hits the pad
			colPAD = true;
		}
		if(bally + 26 >= 550 || bally + 26 <= 575){
			for(int i=0;i<50;i++){
				if(ballx+13==padx+i && colPAD==true && collided>1){  // if the ball hits on the left side and ball already hit a block or wall
					UP = true;
					DOWN = false;// new direction
					LEFT = true;
					RIGHT = false;
				}
			}
			for(int j=50;j<100;j++){
				if(ballx+13==padx+j && colPAD ==true && collided>1){  // if the ball hits on the  right side and ball already hit a block
					UP = true;
					DOWN = false;
					LEFT = false;
					RIGHT = true;
				}
			}
		}
		boolean breakwholeloop = false;
		for(int i = 0;i < 11;i++){
			for(int j = 0;j < 6;j++){
				if(LivesB[j][i] > 0){
					int by = 109 + 31*j; //brick's y value
					int bx = 75 + 60*i; //brick's x value
					
					
					//make sure x is within the brick
					if((ballx >= bx && ballx <= bx + 60) || (ballx + 26 >= bx && ballx + 26 <= bx + 60)){
						
						if((bally >= by + 5 && bally <= by + 26) || (bally + 26 >= by + 5 && bally + 26 <= by + 26)){
							//Hitting on the side
							LivesB[j][i] -= 1;
							if(j!=0){
								deadBlocks+=1;	//hit any block but the silver one because it needs two hits
							}
							
							if(j==5){//add number to score if it hits
								score+=50;
							}
							if(j==4){
								score+=110;
							}
							if(j==3){
								score+=70;
							}
							if(j==2){
								score+=120;
							}
							if(j==1){
								score+=90;
							}
							if(j==0 && LivesB[j][i]==0){//If it hits the silver block twice
								score+=50;
								deadBlocks+=1;
							}
							LEFT = !LEFT;
							RIGHT = !RIGHT;
							breakwholeloop = true;
							break;
						}
						else if ((bally <= by + 5 && bally >= by) || (bally + 26 <= by + 5 && bally + 26 >= by) || (bally <= by + 31 && bally >= by + 26) || (bally + 26 <= by + 31 && bally + 26 >= by + 26)){
							//top/bottom collision
							LivesB[j][i] -= 1;
							if(j!=0){
								deadBlocks+=1;	
							}
							if(j==5){
								score+=50;
							}
							if(j==4){
								score+=110;
							}
							if(j==3){
								score+=70;
							}
							if(j==2){
								score+=120;
							}
							if(j==1){
								score+=90;
							}
							if(j==0 && LivesB[j][i]==0){
								score+=50;
								deadBlocks+=1;
							}
							UP = !UP;
							DOWN = !DOWN;
							breakwholeloop = true;
							break;
						}
					}
				}
			}
			if(breakwholeloop)
				break;
		}
		if(bally>=675){//If it hits the floor
			started = false;
			ballx = 395;//reset value
			bally = 523;
  	  		padx = 360;
   			pady = 550;
			UP = false;
			LEFT = false;
			RIGHT = false;
			DOWN = false;
			collided = 0; 
			Lives-=1;//lose a life
		}
		
		if (new Rectangle(ballx, bally, 28, 28).intersects(new Rectangle(padx, pady, 100, 25))) {//If the ball collides with rectangle
			DOWN = false;
			UP = true;
		}
	}
    public void keyTyped(KeyEvent e) {}

    public void keyPressed(KeyEvent e) {
        keys[e.getKeyCode()] = true;
        if(Lives<=0 && deathTimer>=200){//if you died you have the option to restart by pressing a key and waiting after a timer
    		Lives=3;//resetting values
    		//score=0;
    		started=false;
    		deathTimer=0;
    		int LivesB[][]={
		{2,2,2,2,2,2,2,2,2,2,2},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1}
		
		};
    	}
    	if(deadBlocks==66 && deathTimer>=200){//if you finish the game you have the option to restart by pressing a key and waiting after a timer
    		Lives=3;
    		//score=0;
    		started=false;
    		deathTimer=0;
    		deadBlocks=0;
    		int LivesB[][]={
		{2,2,2,2,2,2,2,2,2,2,2},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1}
		
		};
    	}
    }
    public void keyReleased(KeyEvent e) {
        keys[e.getKeyCode()] = false;
    }
	public void update(){
		Graphics g = getGraphics();
	}
    public void paintComponent(Graphics g){
    
    if(Lives<=0){//display 2 pictures
    		g.setColor(Color.black);
	    	g.fillRect(0, 0, 800, 700);
	    	g.drawImage(Continue,250,400,this);//if you press a key a wait after a timer you restart
	    	g.drawImage(GG,250,200,this);
	    	
	    	
	    	deathTimer+=1;
	    	
    	}	
	
	
	
    if(Lives>0){
    	for(int i=0;i<11;i++){
    		
    	}
    	System.out.println("Your score is " + score);//printing score
    	
	   	g.setColor(Color.black);
	    g.fillRect(0, 0, 800, 700);
	    g.drawImage(back,50,50,this);//display background
	    
	    
	    for(int i=0;i<Lives;i++){// display number of lives
	    		g.drawImage(LivesPic,0+i*50,0,this);
	    	}
		for(int i=0;i<11;i++){//11 colomns
			for(int j=0;j<6;j++){//6 rows
			
				if(j==0){
					
					if(LivesB[j][i]>0){
						g.drawImage(SBrick,75 + i*59,109 + 31*j,this);//display brick row determines the colour
						
					}
					
				}
				if(j==1){
					if(LivesB[j][i]>0){
					g.drawImage(RBrick,75 + i*59,109 + 31*j,this);
					}
				}
				if(j==2){
					if(LivesB[j][i]>0){
					g.drawImage(YBrick,75 + i*59,109 + 31*j,this);
					}
				}
				if(j==3){
					if(LivesB[j][i]>0){
					g.drawImage(DBBrick,75 + i*59,109 + 31*j,this);
					}
				}
				if(j==4){
					if(LivesB[j][i]>0){
					g.drawImage(PBrick,75 + i*59,109 + 31*j,this);
					}
				}
				if(j==5){
					if(LivesB[j][i]>0){
					g.drawImage(GBrick,75 + i*59,109 + 31*j,this);
					}
					if(LivesB[j][i]<1){
						
					}
				}
				if(i==11 && j<6){
	    				i=0;
	    			}
				}
	    			
			}
		
		//g.drawImage(back,0,0,this);
	   	g.drawImage(pad,padx,pady,this);
	   	g.drawImage(ball,ballx,bally,this);
	    
		//System.out.println(score5);
		
		if(started==true){
			
			
			if(UP){
				bally -= 2;//go up by reducing y
			}
			if(DOWN){
				bally += 2;//go down by increasing y
			}
			if(LEFT){
				ballx -= 2;//go left by decreasing
			}
			if(RIGHT){
				ballx += 2;//go right by decreasing
			}
			moveBall();//call method
		}
	    }
	    if(deadBlocks==66){//finished game all blocks dead
	    	g.setColor(Color.black);
	    	g.fillRect(0, 0, 800, 700);
	    	g.drawImage(LevelComplete,250,400,this);
	    	g.drawImage(GG,250,200,this);
	    	
	    	
	    	deathTimer+=1;//when timer is 200 you can press a key to restart
	    }
    }
}


    
